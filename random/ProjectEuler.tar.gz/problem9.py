#!/usr/bin/python
import math

list = []
a = 3
for i in range(1,100):
	if(a%2==0):
		b = a**2 / 4
		c = b + 2
		sumOf = a + b + c
		if sumOf == 1000:
			prod = a*b*c
			list.append(prod)
	else:
	 	b = a**2 / 2 - 1/2
	 	c = b + 1
	 	sumOf = a + b + c
	 	if sumOf == 1000:
			list.append(a*b*c)
print list
